export const environment = {
  production: true,
  apiURL: "https://marina-spot.herokuapp.com/api/"
};
